// const sign = document.querySelector(".sign")
// const login = document.querySelector(".login")

// const sign_form = document.querySelector(".sign_form")
// const login_form = document.querySelector(".login_form")

// const ferdi_sexs= document.querySelector(".ferdi-sexs-form")
// const biznes_form = document.querySelector(".biznes-form")


// const sign_now = () =>{
//     sign_form.classList.remove("hidden")
//     biznes_form.classList.add("hidden")

// }


// sign.addEventListener('click',sign_now)
